#ifndef CLIENT_H
#define CLIENT_H

#include <string>

enum class ServiceType
{
    Brokerage = 1,
    Retirement = 2
};

// Stores one client record.
class Client
{
public:
    Client(int id, const std::string& name, ServiceType service);

    int getId() const;
    const std::string& getName() const;
    ServiceType getService() const;
    void setService(ServiceType service);

    static bool isValidService(ServiceType service);
    static std::string serviceToString(ServiceType service);

private:
    int id_;
    std::string name_;
    ServiceType service_;
};

#endif
