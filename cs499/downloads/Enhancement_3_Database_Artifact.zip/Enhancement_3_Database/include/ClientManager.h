#ifndef CLIENT_MANAGER_H
#define CLIENT_MANAGER_H

#include "Client.h"

#include <iosfwd>
#include <unordered_map>
#include <vector>

class DatabaseManager;

// Uses the database for persistence and an unordered map for fast ID lookup.
class ClientManager
{
public:
    explicit ClientManager(DatabaseManager& database);

    void displayClientsById(std::ostream& output) const;
    bool displayClientById(int clientId, std::ostream& output) const;
    void displayClientsSortedByName(std::ostream& output) const;
    void displayClientsSortedByService(std::ostream& output) const;
    void displayClientsByService(ServiceType service, std::ostream& output) const;
    void displayAuditLog(std::ostream& output) const;
    bool updateClientService(int clientId, ServiceType service);

private:
    void reloadClients();
    const Client* findClientById(int clientId) const;
    std::vector<Client> copyClients() const;
    static void displayList(const std::vector<Client>& clients, std::ostream& output);
    static void displayClient(const Client& client, std::ostream& output);

    DatabaseManager& database_;
    std::unordered_map<int, Client> clients_;
};

#endif
