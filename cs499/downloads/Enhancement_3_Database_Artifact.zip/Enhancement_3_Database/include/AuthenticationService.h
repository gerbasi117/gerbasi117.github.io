#ifndef AUTHENTICATION_SERVICE_H
#define AUTHENTICATION_SERVICE_H

#include <cstdint>
#include <iosfwd>
#include <string>

class DatabaseManager;

enum class LoginResult
{
    Success,
    Denied,
    InputClosed
};

// Checks user credentials stored in the database.
class AuthenticationService
{
public:
    explicit AuthenticationService(DatabaseManager& database, int maxAttempts = 3);

    LoginResult authenticate(std::istream& input, std::ostream& output) const;

private:
    static std::uint64_t hashPassword(const std::string& password);

    DatabaseManager& database_;
    int maxAttempts_;
};

#endif
