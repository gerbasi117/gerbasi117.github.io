#ifndef DATABASE_MANAGER_H
#define DATABASE_MANAGER_H

#include "Client.h"

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

struct sqlite3;

struct AuditRecord
{
    int id;
    int clientId;
    ServiceType oldService;
    ServiceType newService;
    std::string changedAt;
};

// Manages the SQLite database and all SQL operations.
class DatabaseManager
{
public:
    explicit DatabaseManager(const std::string& databasePath);
    ~DatabaseManager();

    DatabaseManager(const DatabaseManager&) = delete;
    DatabaseManager& operator=(const DatabaseManager&) = delete;

    bool authenticateUser(const std::string& username, std::uint64_t passwordHash) const;
    std::vector<Client> loadClients() const;
    bool updateClientService(int clientId, ServiceType newService);
    std::vector<AuditRecord> loadAuditLog() const;

private:
    void execute(const std::string& sql) const;
    void createTables();
    void seedData();
    void rollbackQuietly() const;

    sqlite3* database_;
};

#endif
