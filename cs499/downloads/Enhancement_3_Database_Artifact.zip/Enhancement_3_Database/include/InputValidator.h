#ifndef INPUT_VALIDATOR_H
#define INPUT_VALIDATOR_H

#include <cstddef>
#include <iosfwd>
#include <optional>
#include <string>

// Reads complete lines and checks numeric input.
class InputValidator
{
public:
    static constexpr std::size_t MAX_INPUT_LENGTH = 256;

    // An empty optional means the input has ended.
    static std::optional<std::string> getLine(
        const std::string& prompt,
        std::istream& input,
        std::ostream& output
    );

    static std::optional<int> getIntegerInRange(
        const std::string& prompt,
        int minValue,
        int maxValue,
        std::istream& input,
        std::ostream& output
    );
};

#endif
