#include "InputValidator.h"

#include <istream>
#include <ostream>
#include <sstream>
#include <stdexcept>

std::optional<std::string> InputValidator::getLine(
    const std::string& prompt,
    std::istream& input,
    std::ostream& output
)
{
    while (true)
    {
        output << prompt << std::flush;
        std::string line;
        char character = '\0';
        bool tooLong = false;

        // Keep at most 257 bytes, but consume the whole line.
        while (input.get(character) && character != '\n')
        {
            if (line.size() <= MAX_INPUT_LENGTH)
            {
                line += character;
            }
            else
            {
                tooLong = true;
            }
        }

        if (input.bad() || (input.fail() && !input.eof()))
        {
            throw std::runtime_error("Could not read input.");
        }

        if (input.eof() && line.empty() && !tooLong)
        {
            return std::nullopt;
        }

        if (!line.empty() && line.back() == '\r')
        {
            line.pop_back();
        }

        if (tooLong || line.size() > MAX_INPUT_LENGTH)
        {
            output << "Input is too long. Use at most "
                   << MAX_INPUT_LENGTH << " bytes.\n";
            if (input.eof())
            {
                return std::nullopt;
            }
            continue;
        }

        return line;
    }
}

std::optional<int> InputValidator::getIntegerInRange(
    const std::string& prompt,
    int minValue,
    int maxValue,
    std::istream& input,
    std::ostream& output
)
{
    if (minValue > maxValue)
    {
        throw std::invalid_argument("Input range is not valid.");
    }

    while (true)
    {
        const auto line = getLine(prompt, input, output);
        if (!line)
        {
            return std::nullopt;
        }

        std::istringstream parser(*line);
        int value = 0;
        char extra = '\0';

        if ((parser >> value) && !(parser >> extra) &&
            value >= minValue && value <= maxValue)
        {
            return value;
        }

        output << "Invalid input. Please enter a whole number from "
               << minValue << " to " << maxValue << ".\n";
    }
}
