#include "ClientManager.h"
#include "DatabaseManager.h"

#include <algorithm>
#include <ostream>

ClientManager::ClientManager(DatabaseManager& database)
    : database_(database)
{
    reloadClients();
}

void ClientManager::reloadClients()
{
    clients_.clear();

    for (const Client& client : database_.loadClients())
    {
        clients_.emplace(client.getId(), client);
    }
}

const Client* ClientManager::findClientById(int clientId) const
{
    const auto match = clients_.find(clientId);
    if (match == clients_.end())
    {
        return nullptr;
    }

    return &match->second;
}

std::vector<Client> ClientManager::copyClients() const
{
    std::vector<Client> clients;
    clients.reserve(clients_.size());

    for (const auto& entry : clients_)
    {
        clients.push_back(entry.second);
    }

    return clients;
}

void ClientManager::displayClient(const Client& client, std::ostream& output)
{
    output << "ID " << client.getId() << ": " << client.getName()
           << " - " << Client::serviceToString(client.getService()) << '\n';
}

void ClientManager::displayList(const std::vector<Client>& clients, std::ostream& output)
{
    if (clients.empty())
    {
        output << "No matching clients were found.\n";
        return;
    }

    for (const Client& client : clients)
    {
        displayClient(client, output);
    }
}

void ClientManager::displayClientsById(std::ostream& output) const
{
    auto clients = copyClients();
    std::sort(clients.begin(), clients.end(), [](const Client& left, const Client& right)
    {
        return left.getId() < right.getId();
    });

    output << "\nClients sorted by ID\n";
    displayList(clients, output);
}

bool ClientManager::displayClientById(int clientId, std::ostream& output) const
{
    const Client* client = findClientById(clientId);
    if (client == nullptr)
    {
        output << "Client ID was not found.\n";
        return false;
    }

    displayClient(*client, output);
    return true;
}

void ClientManager::displayClientsSortedByName(std::ostream& output) const
{
    auto clients = copyClients();
    std::sort(clients.begin(), clients.end(), [](const Client& left, const Client& right)
    {
        if (left.getName() == right.getName())
        {
            return left.getId() < right.getId();
        }
        return left.getName() < right.getName();
    });

    output << "\nClients sorted by name\n";
    displayList(clients, output);
}

void ClientManager::displayClientsSortedByService(std::ostream& output) const
{
    auto clients = copyClients();
    std::sort(clients.begin(), clients.end(), [](const Client& left, const Client& right)
    {
        const int leftService = static_cast<int>(left.getService());
        const int rightService = static_cast<int>(right.getService());

        if (leftService == rightService)
        {
            return left.getName() < right.getName();
        }
        return leftService < rightService;
    });

    output << "\nClients sorted by service\n";
    displayList(clients, output);
}

void ClientManager::displayClientsByService(ServiceType service, std::ostream& output) const
{
    std::vector<Client> matches;

    for (const auto& entry : clients_)
    {
        if (entry.second.getService() == service)
        {
            matches.push_back(entry.second);
        }
    }

    std::sort(matches.begin(), matches.end(), [](const Client& left, const Client& right)
    {
        return left.getName() < right.getName();
    });

    output << "\nClients using " << Client::serviceToString(service) << '\n';
    displayList(matches, output);
}

void ClientManager::displayAuditLog(std::ostream& output) const
{
    const auto records = database_.loadAuditLog();
    output << "\nClient service audit log\n";

    if (records.empty())
    {
        output << "No service changes have been recorded.\n";
        return;
    }

    for (const AuditRecord& record : records)
    {
        output << "Entry " << record.id
               << ": client " << record.clientId
               << " changed from " << Client::serviceToString(record.oldService)
               << " to " << Client::serviceToString(record.newService)
               << " at " << record.changedAt << '\n';
    }
}

bool ClientManager::updateClientService(int clientId, ServiceType service)
{
    if (!Client::isValidService(service) || findClientById(clientId) == nullptr)
    {
        return false;
    }

    if (!database_.updateClientService(clientId, service))
    {
        return false;
    }

    clients_.at(clientId).setService(service);
    return true;
}
