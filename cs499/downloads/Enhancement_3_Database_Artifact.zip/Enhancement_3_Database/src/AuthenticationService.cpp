#include "AuthenticationService.h"
#include "DatabaseManager.h"
#include "InputValidator.h"

#include <ostream>
#include <stdexcept>

AuthenticationService::AuthenticationService(DatabaseManager& database, int maxAttempts)
    : database_(database), maxAttempts_(maxAttempts)
{
    if (maxAttempts_ < 1)
    {
        throw std::invalid_argument("Login attempts must be at least one.");
    }
}

std::uint64_t AuthenticationService::hashPassword(const std::string& password)
{
    // Demo only. A real system should use a dedicated password-hashing method.
    std::uint64_t hash = 1469598103934665603ULL;

    for (char character : password)
    {
        hash ^= static_cast<unsigned char>(character);
        hash *= 1099511628211ULL;
    }

    return hash;
}

LoginResult AuthenticationService::authenticate(
    std::istream& input,
    std::ostream& output
) const
{
    for (int remaining = maxAttempts_; remaining > 0; --remaining)
    {
        const auto username = InputValidator::getLine("Enter your username: ", input, output);
        if (!username)
        {
            return LoginResult::InputClosed;
        }

        const auto password = InputValidator::getLine("Enter your password: ", input, output);
        if (!password)
        {
            return LoginResult::InputClosed;
        }

        if (database_.authenticateUser(*username, hashPassword(*password)))
        {
            return LoginResult::Success;
        }

        output << "Invalid username or password. Attempts remaining: "
               << (remaining - 1) << '\n';
    }

    return LoginResult::Denied;
}
