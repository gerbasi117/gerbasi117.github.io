#include "DatabaseManager.h"

#include <sqlite3.h>

#include <stdexcept>
#include <string>

namespace
{
    constexpr std::uint64_t DEMO_PASSWORD_HASH = 4591456448132287629ULL;

    class Statement
    {
    public:
        Statement(sqlite3* database, const char* sql)
            : statement_(nullptr)
        {
            if (sqlite3_prepare_v2(database, sql, -1, &statement_, nullptr) != SQLITE_OK)
            {
                throw std::runtime_error(sqlite3_errmsg(database));
            }
        }

        ~Statement()
        {
            sqlite3_finalize(statement_);
        }

        sqlite3_stmt* get() const
        {
            return statement_;
        }

    private:
        sqlite3_stmt* statement_;
    };

    void requireBind(int result, sqlite3* database)
    {
        if (result != SQLITE_OK)
        {
            throw std::runtime_error(sqlite3_errmsg(database));
        }
    }

    void requireDone(int result, sqlite3* database)
    {
        if (result != SQLITE_DONE)
        {
            throw std::runtime_error(sqlite3_errmsg(database));
        }
    }
}

DatabaseManager::DatabaseManager(const std::string& databasePath)
    : database_(nullptr)
{
    if (sqlite3_open(databasePath.c_str(), &database_) != SQLITE_OK)
    {
        const std::string message = database_ == nullptr
            ? "Could not open the database."
            : sqlite3_errmsg(database_);
        if (database_ != nullptr)
        {
            sqlite3_close(database_);
            database_ = nullptr;
        }
        throw std::runtime_error(message);
    }

    try
    {
        execute("PRAGMA foreign_keys = ON;");
        createTables();
        seedData();
    }
    catch (...)
    {
        sqlite3_close(database_);
        database_ = nullptr;
        throw;
    }
}

DatabaseManager::~DatabaseManager()
{
    if (database_ != nullptr)
    {
        sqlite3_close(database_);
    }
}

void DatabaseManager::execute(const std::string& sql) const
{
    char* errorMessage = nullptr;
    const int result = sqlite3_exec(database_, sql.c_str(), nullptr, nullptr, &errorMessage);

    if (result != SQLITE_OK)
    {
        const std::string message = errorMessage == nullptr
            ? sqlite3_errmsg(database_)
            : errorMessage;
        sqlite3_free(errorMessage);
        throw std::runtime_error(message);
    }
}

void DatabaseManager::rollbackQuietly() const
{
    char* errorMessage = nullptr;
    sqlite3_exec(database_, "ROLLBACK;", nullptr, nullptr, &errorMessage);
    sqlite3_free(errorMessage);
}

void DatabaseManager::createTables()
{
    execute(
        "CREATE TABLE IF NOT EXISTS users ("
        "username TEXT PRIMARY KEY, "
        "password_hash TEXT NOT NULL"
        ");"
    );

    execute(
        "CREATE TABLE IF NOT EXISTS clients ("
        "id INTEGER PRIMARY KEY, "
        "name TEXT NOT NULL CHECK(length(trim(name)) > 0), "
        "service INTEGER NOT NULL CHECK(service IN (1, 2))"
        ");"
    );

    execute(
        "CREATE TABLE IF NOT EXISTS audit_log ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "client_id INTEGER NOT NULL, "
        "old_service INTEGER NOT NULL CHECK(old_service IN (1, 2)), "
        "new_service INTEGER NOT NULL CHECK(new_service IN (1, 2)), "
        "changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, "
        "FOREIGN KEY(client_id) REFERENCES clients(id)"
        ");"
    );
}

void DatabaseManager::seedData()
{
    execute("BEGIN TRANSACTION;");

    try
    {
        Statement userStatement(
            database_,
            "INSERT OR IGNORE INTO users(username, password_hash) VALUES(?, ?);"
        );
        const std::string passwordHash = std::to_string(DEMO_PASSWORD_HASH);
        requireBind(
            sqlite3_bind_text(userStatement.get(), 1, "Brandon", -1, SQLITE_STATIC),
            database_
        );
        requireBind(
            sqlite3_bind_text(
                userStatement.get(), 2, passwordHash.c_str(), -1, SQLITE_TRANSIENT
            ),
            database_
        );
        requireDone(sqlite3_step(userStatement.get()), database_);

        Statement clientStatement(
            database_,
            "INSERT OR IGNORE INTO clients(id, name, service) VALUES(?, ?, ?);"
        );

        struct SeedClient
        {
            int id;
            const char* name;
            ServiceType service;
        };

        const SeedClient seedClients[] = {
            {1001, "Bob Jones", ServiceType::Brokerage},
            {1002, "Sarah Davis", ServiceType::Retirement},
            {1003, "Amy Friendly", ServiceType::Brokerage},
            {1004, "Johnny Smith", ServiceType::Brokerage},
            {1005, "Carol Spears", ServiceType::Retirement}
        };

        for (const SeedClient& client : seedClients)
        {
            sqlite3_reset(clientStatement.get());
            sqlite3_clear_bindings(clientStatement.get());

            requireBind(sqlite3_bind_int(clientStatement.get(), 1, client.id), database_);
            requireBind(
                sqlite3_bind_text(clientStatement.get(), 2, client.name, -1, SQLITE_STATIC),
                database_
            );
            requireBind(
                sqlite3_bind_int(
                    clientStatement.get(), 3, static_cast<int>(client.service)
                ),
                database_
            );
            requireDone(sqlite3_step(clientStatement.get()), database_);
        }

        execute("COMMIT;");
    }
    catch (...)
    {
        rollbackQuietly();
        throw;
    }
}

bool DatabaseManager::authenticateUser(
    const std::string& username,
    std::uint64_t passwordHash
) const
{
    Statement statement(
        database_,
        "SELECT 1 FROM users WHERE username = ? AND password_hash = ?;"
    );

    const std::string hashText = std::to_string(passwordHash);
    requireBind(
        sqlite3_bind_text(statement.get(), 1, username.c_str(), -1, SQLITE_TRANSIENT),
        database_
    );
    requireBind(
        sqlite3_bind_text(statement.get(), 2, hashText.c_str(), -1, SQLITE_TRANSIENT),
        database_
    );

    const int result = sqlite3_step(statement.get());
    if (result == SQLITE_ROW)
    {
        return true;
    }
    if (result == SQLITE_DONE)
    {
        return false;
    }

    throw std::runtime_error(sqlite3_errmsg(database_));
}

std::vector<Client> DatabaseManager::loadClients() const
{
    Statement statement(
        database_,
        "SELECT id, name, service FROM clients ORDER BY id;"
    );

    std::vector<Client> clients;
    int result = SQLITE_ROW;

    while ((result = sqlite3_step(statement.get())) == SQLITE_ROW)
    {
        const int id = sqlite3_column_int(statement.get(), 0);
        const unsigned char* nameText = sqlite3_column_text(statement.get(), 1);
        const int serviceValue = sqlite3_column_int(statement.get(), 2);

        if (nameText == nullptr)
        {
            throw std::runtime_error("A client name was missing from the database.");
        }

        clients.emplace_back(
            id,
            reinterpret_cast<const char*>(nameText),
            static_cast<ServiceType>(serviceValue)
        );
    }

    if (result != SQLITE_DONE)
    {
        throw std::runtime_error(sqlite3_errmsg(database_));
    }

    return clients;
}

bool DatabaseManager::updateClientService(int clientId, ServiceType newService)
{
    if (!Client::isValidService(newService))
    {
        return false;
    }

    execute("BEGIN IMMEDIATE TRANSACTION;");

    try
    {
        ServiceType oldService = ServiceType::Brokerage;
        {
            Statement selectStatement(
                database_,
                "SELECT service FROM clients WHERE id = ?;"
            );
            requireBind(sqlite3_bind_int(selectStatement.get(), 1, clientId), database_);

            const int selectResult = sqlite3_step(selectStatement.get());
            if (selectResult == SQLITE_DONE)
            {
                execute("ROLLBACK;");
                return false;
            }
            if (selectResult != SQLITE_ROW)
            {
                throw std::runtime_error(sqlite3_errmsg(database_));
            }

            oldService = static_cast<ServiceType>(
                sqlite3_column_int(selectStatement.get(), 0)
            );
        }

        if (oldService == newService)
        {
            execute("COMMIT;");
            return true;
        }

        Statement updateStatement(
            database_,
            "UPDATE clients SET service = ? WHERE id = ?;"
        );
        requireBind(
            sqlite3_bind_int(
                updateStatement.get(), 1, static_cast<int>(newService)
            ),
            database_
        );
        requireBind(sqlite3_bind_int(updateStatement.get(), 2, clientId), database_);
        requireDone(sqlite3_step(updateStatement.get()), database_);

        Statement auditStatement(
            database_,
            "INSERT INTO audit_log(client_id, old_service, new_service) "
            "VALUES(?, ?, ?);"
        );
        requireBind(sqlite3_bind_int(auditStatement.get(), 1, clientId), database_);
        requireBind(
            sqlite3_bind_int(
                auditStatement.get(), 2, static_cast<int>(oldService)
            ),
            database_
        );
        requireBind(
            sqlite3_bind_int(
                auditStatement.get(), 3, static_cast<int>(newService)
            ),
            database_
        );
        requireDone(sqlite3_step(auditStatement.get()), database_);

        execute("COMMIT;");
        return true;
    }
    catch (...)
    {
        rollbackQuietly();
        throw;
    }
}

std::vector<AuditRecord> DatabaseManager::loadAuditLog() const
{
    Statement statement(
        database_,
        "SELECT id, client_id, old_service, new_service, changed_at "
        "FROM audit_log ORDER BY id;"
    );

    std::vector<AuditRecord> records;
    int result = SQLITE_ROW;

    while ((result = sqlite3_step(statement.get())) == SQLITE_ROW)
    {
        const unsigned char* changedAtText = sqlite3_column_text(statement.get(), 4);
        if (changedAtText == nullptr)
        {
            throw std::runtime_error("An audit date was missing from the database.");
        }

        records.push_back(AuditRecord{
            sqlite3_column_int(statement.get(), 0),
            sqlite3_column_int(statement.get(), 1),
            static_cast<ServiceType>(sqlite3_column_int(statement.get(), 2)),
            static_cast<ServiceType>(sqlite3_column_int(statement.get(), 3)),
            reinterpret_cast<const char*>(changedAtText)
        });
    }

    if (result != SQLITE_DONE)
    {
        throw std::runtime_error(sqlite3_errmsg(database_));
    }

    return records;
}
