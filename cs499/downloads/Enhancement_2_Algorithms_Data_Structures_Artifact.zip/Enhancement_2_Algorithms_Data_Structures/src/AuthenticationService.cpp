#include "AuthenticationService.h"
#include "InputValidator.h"

#include <ostream>
#include <stdexcept>

AuthenticationService::AuthenticationService(
    const std::string& allowedUsername,
    std::uint64_t expectedPasswordHash,
    int maxAttempts
)
    : allowedUsername_(allowedUsername),
      expectedPasswordHash_(expectedPasswordHash),
      maxAttempts_(maxAttempts)
{
    if (allowedUsername_.find_first_not_of(" \t\r\n") == std::string::npos ||
        allowedUsername_.size() > InputValidator::MAX_INPUT_LENGTH)
    {
        throw std::invalid_argument("Demo username is not valid.");
    }

    if (maxAttempts_ < 1)
    {
        throw std::invalid_argument("Login attempts must be at least one.");
    }
}

std::uint64_t AuthenticationService::hashPassword(const std::string& password)
{
    // Demo only. This is not a safe way to store real passwords.
    std::uint64_t hash = 1469598103934665603ULL;

    for (char character : password)
    {
        hash ^= static_cast<unsigned char>(character);
        hash *= 1099511628211ULL;
    }

    return hash;
}

LoginResult AuthenticationService::authenticate(
    std::istream& input,
    std::ostream& output
) const
{
    for (int remaining = maxAttempts_; remaining > 0; --remaining)
    {
        const auto username = InputValidator::getLine("Enter your username: ", input, output);
        if (!username)
        {
            return LoginResult::InputClosed;
        }

        const auto password = InputValidator::getLine("Enter your password: ", input, output);
        if (!password)
        {
            return LoginResult::InputClosed;
        }

        if (*username == allowedUsername_ &&
            hashPassword(*password) == expectedPasswordHash_)
        {
            return LoginResult::Success;
        }

        output << "Invalid username or password. Attempts remaining: "
               << (remaining - 1) << '\n';
    }

    return LoginResult::Denied;
}
