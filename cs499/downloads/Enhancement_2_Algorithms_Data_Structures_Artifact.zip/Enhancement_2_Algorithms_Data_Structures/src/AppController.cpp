#include "AppController.h"
#include "InputValidator.h"

#include <cstdint>
#include <ostream>
#include <stdexcept>

namespace
{
    // Hash for the demo password "123". Do not use it for real accounts.
    constexpr std::uint64_t DEMO_PASSWORD_HASH = 4591456448132287629ULL;
}

AppController::AppController()
    : authenticationService_("Brandon", DEMO_PASSWORD_HASH, 3),
      clientManager_()
{
}

void AppController::displayMenu(std::ostream& output) const
{
    output << "\nWhat would you like to do?\n";
    output << "1. Display clients by ID\n";
    output << "2. Find a client by ID\n";
    output << "3. Sort clients by name\n";
    output << "4. Sort clients by service\n";
    output << "5. Filter clients by service\n";
    output << "6. Change a client's service\n";
    output << "7. Exit\n";
}

bool AppController::findClient(std::istream& input, std::ostream& output) const
{
    const auto clientId = InputValidator::getIntegerInRange(
        "Enter the client ID: ", 1, 999999, input, output
    );
    if (!clientId)
    {
        return false;
    }

    clientManager_.displayClientById(*clientId, output);
    return true;
}

bool AppController::filterClients(std::istream& input, std::ostream& output) const
{
    const auto service = InputValidator::getIntegerInRange(
        "Enter the service (1 = Brokerage, 2 = Retirement): ",
        1, 2, input, output
    );
    if (!service)
    {
        return false;
    }

    clientManager_.displayClientsByService(static_cast<ServiceType>(*service), output);
    return true;
}

bool AppController::updateClient(std::istream& input, std::ostream& output)
{
    const auto clientId = InputValidator::getIntegerInRange(
        "Enter the client ID to change: ", 1, 999999, input, output
    );
    if (!clientId)
    {
        return false;
    }

    const auto service = InputValidator::getIntegerInRange(
        "Enter the new service (1 = Brokerage, 2 = Retirement): ",
        1, 2, input, output
    );
    if (!service)
    {
        return false;
    }

    if (clientManager_.updateClientService(*clientId, static_cast<ServiceType>(*service)))
    {
        output << "Client service choice updated successfully.\n";
    }
    else
    {
        output << "Client ID was not found.\n";
    }

    return true;
}

int AppController::run(std::istream& input, std::ostream& output)
{
    output << "CS 499 Algorithms and Data Structures Enhancement\n";
    output << "Investment Company Client Service Application\n";

    const LoginResult login = authenticationService_.authenticate(input, output);
    if (login == LoginResult::Denied)
    {
        output << "Access denied. Too many failed login attempts.\n";
        return 1;
    }
    if (login == LoginResult::InputClosed)
    {
        output << "Input closed. Exiting program.\n";
        return 0;
    }

    while (true)
    {
        displayMenu(output);
        const auto choice = InputValidator::getIntegerInRange(
            "Enter your choice: ", 1, 7, input, output
        );
        if (!choice)
        {
            output << "Input closed. Exiting program.\n";
            return 0;
        }

        switch (*choice)
        {
            case 1:
                clientManager_.displayClientsById(output);
                break;
            case 2:
                if (!findClient(input, output))
                {
                    output << "Input closed. Exiting program.\n";
                    return 0;
                }
                break;
            case 3:
                clientManager_.displayClientsSortedByName(output);
                break;
            case 4:
                clientManager_.displayClientsSortedByService(output);
                break;
            case 5:
                if (!filterClients(input, output))
                {
                    output << "Input closed. Exiting program.\n";
                    return 0;
                }
                break;
            case 6:
                if (!updateClient(input, output))
                {
                    output << "Input closed. Exiting program.\n";
                    return 0;
                }
                break;
            case 7:
                output << "Exiting program.\n";
                return 0;
            default:
                throw std::logic_error("Menu choice was not validated.");
        }
    }
}
