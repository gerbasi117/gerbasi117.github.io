#include "AppController.h"

#include <exception>
#include <iostream>

int main()
{
    try
    {
        // Use C++ streams so input read errors can be reported.
        std::ios::sync_with_stdio(false);
        AppController application;
        return application.run(std::cin, std::cout);
    }
    catch (const std::exception& error)
    {
        std::cerr << "Unable to continue: " << error.what() << '\n';
        return 2;
    }
}
