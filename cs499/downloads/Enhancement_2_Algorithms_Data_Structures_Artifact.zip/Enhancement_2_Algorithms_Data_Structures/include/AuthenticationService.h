#ifndef AUTHENTICATION_SERVICE_H
#define AUTHENTICATION_SERVICE_H

#include <cstdint>
#include <iosfwd>
#include <string>

enum class LoginResult
{
    Success,
    Denied,
    InputClosed
};

// Checks the demo account and limits failed login attempts.
class AuthenticationService
{
public:
    AuthenticationService(
        const std::string& allowedUsername,
        std::uint64_t expectedPasswordHash,
        int maxAttempts = 3
    );

    LoginResult authenticate(std::istream& input, std::ostream& output) const;

private:
    static std::uint64_t hashPassword(const std::string& password);

    std::string allowedUsername_;
    std::uint64_t expectedPasswordHash_;
    int maxAttempts_;
};

#endif
