#ifndef APP_CONTROLLER_H
#define APP_CONTROLLER_H

#include "AuthenticationService.h"
#include "ClientManager.h"

#include <iosfwd>

// Handles the menu and sends requests to the client manager.
class AppController
{
public:
    AppController();
    int run(std::istream& input, std::ostream& output);

private:
    void displayMenu(std::ostream& output) const;
    bool findClient(std::istream& input, std::ostream& output) const;
    bool filterClients(std::istream& input, std::ostream& output) const;
    bool updateClient(std::istream& input, std::ostream& output);

    AuthenticationService authenticationService_;
    ClientManager clientManager_;
};

#endif
