#ifndef CLIENT_MANAGER_H
#define CLIENT_MANAGER_H

#include "Client.h"

#include <iosfwd>
#include <unordered_map>
#include <vector>

// Stores clients by ID and provides search, sort, filter, and update operations.
class ClientManager
{
public:
    ClientManager();

    void displayClientsById(std::ostream& output) const;
    bool displayClientById(int clientId, std::ostream& output) const;
    void displayClientsSortedByName(std::ostream& output) const;
    void displayClientsSortedByService(std::ostream& output) const;
    void displayClientsByService(ServiceType service, std::ostream& output) const;
    bool updateClientService(int clientId, ServiceType service);

private:
    const Client* findClientById(int clientId) const;
    std::vector<Client> copyClients() const;
    static void displayList(const std::vector<Client>& clients, std::ostream& output);
    static void displayClient(const Client& client, std::ostream& output);

    std::unordered_map<int, Client> clients_;
};

#endif
