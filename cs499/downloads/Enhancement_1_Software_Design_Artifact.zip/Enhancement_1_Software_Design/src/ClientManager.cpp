#include "ClientManager.h"

#include <ostream>
#include <utility>

ClientManager::ClientManager()
    : clients_{
          Client("Bob Jones", ServiceType::Brokerage),
          Client("Sarah Davis", ServiceType::Retirement),
          Client("Amy Friendly", ServiceType::Brokerage),
          Client("Johnny Smith", ServiceType::Brokerage),
          Client("Carol Spears", ServiceType::Retirement)
      }
{
}

ClientManager::ClientManager(std::vector<Client> clients)
    : clients_(std::move(clients))
{
}

std::size_t ClientManager::getClientCount() const
{
    return clients_.size();
}

void ClientManager::displayClients(std::ostream& output) const
{
    output << "\nClient List\n-----------\n";
    if (clients_.empty())
    {
        output << "No clients are available.\n";
        return;
    }

    for (std::size_t i = 0; i < clients_.size(); ++i)
    {
        const Client& client = clients_[i];
        output << (i + 1) << ". " << client.getName()
               << " selected " << Client::serviceToString(client.getService()) << '\n';
    }
    output << '\n';
}

bool ClientManager::updateClientService(std::size_t clientNumber, ServiceType service)
{
    // Check the request before changing any client data.
    if (clientNumber < 1 || clientNumber > clients_.size() ||
        !Client::isValidService(service))
    {
        return false;
    }

    clients_.at(clientNumber - 1).setService(service);
    return true;
}
