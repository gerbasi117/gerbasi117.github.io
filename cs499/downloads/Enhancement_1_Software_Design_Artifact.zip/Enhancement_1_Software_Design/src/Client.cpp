#include "Client.h"

#include <stdexcept>

Client::Client(const std::string& name, ServiceType service)
    : name_(name), service_(service)
{
    if (name_.find_first_not_of(" \t\r\n") == std::string::npos)
    {
        throw std::invalid_argument("Client name cannot be blank.");
    }

    if (!isValidService(service))
    {
        throw std::invalid_argument("Client service is not valid.");
    }
}

const std::string& Client::getName() const
{
    return name_;
}

ServiceType Client::getService() const
{
    return service_;
}

void Client::setService(ServiceType service)
{
    // Check here too, so callers cannot store an invalid service.
    if (!isValidService(service))
    {
        throw std::invalid_argument("Client service is not valid.");
    }

    service_ = service;
}

bool Client::isValidService(ServiceType service)
{
    return service == ServiceType::Brokerage || service == ServiceType::Retirement;
}

std::string Client::serviceToString(ServiceType service)
{
    switch (service)
    {
        case ServiceType::Brokerage:
            return "Brokerage";
        case ServiceType::Retirement:
            return "Retirement";
        default:
            return "Unknown";
    }
}
