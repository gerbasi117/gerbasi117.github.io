#include "AppController.h"
#include "InputValidator.h"

#include <cstdint>
#include <limits>
#include <ostream>
#include <stdexcept>

namespace
{
    // Hash for the demo password "123". Do not use it for real accounts.
    constexpr std::uint64_t DEMO_PASSWORD_HASH = 4591456448132287629ULL;
}

AppController::AppController()
    : authenticationService_("Brandon", DEMO_PASSWORD_HASH, 3),
      clientManager_()
{
}

void AppController::displayMenu(std::ostream& output) const
{
    output << "\nWhat would you like to do?\n";
    output << "1. Display the client list\n";
    output << "2. Change a client's service\n";
    output << "3. Exit\n";
}

bool AppController::updateClient(std::istream& input, std::ostream& output)
{
    const std::size_t count = clientManager_.getClientCount();
    if (count == 0)
    {
        output << "No clients are available.\n";
        return true;
    }

    if (count > static_cast<std::size_t>(std::numeric_limits<int>::max()))
    {
        throw std::runtime_error("Too many clients for this menu.");
    }

    const auto clientNumber = InputValidator::getIntegerInRange(
        "Enter the number of the client that you wish to change: ",
        1, static_cast<int>(count), input, output
    );
    if (!clientNumber)
    {
        return false;
    }

    const auto service = InputValidator::getIntegerInRange(
        "Enter the new service (1 = Brokerage, 2 = Retirement): ",
        1, 2, input, output
    );
    if (!service)
    {
        return false;
    }

    const bool updated = clientManager_.updateClientService(
        static_cast<std::size_t>(*clientNumber), static_cast<ServiceType>(*service)
    );
    output << (updated ? "Client service choice updated successfully.\n"
                       : "Client service could not be updated.\n");
    return true;
}

int AppController::run(std::istream& input, std::ostream& output)
{
    output << "CS 499 Software Design/Engineering Enhancement\n";
    output << "Investment Company Client Service Application\n";

    const LoginResult login = authenticationService_.authenticate(input, output);
    if (login == LoginResult::Denied)
    {
        output << "Access denied. Too many failed login attempts.\n";
        return 1;
    }
    if (login == LoginResult::InputClosed)
    {
        output << "Input closed. Exiting program.\n";
        return 0;
    }

    while (true)
    {
        displayMenu(output);
        const auto choice = InputValidator::getIntegerInRange(
            "Enter your choice: ", 1, 3, input, output
        );
        if (!choice)
        {
            output << "Input closed. Exiting program.\n";
            return 0;
        }

        switch (*choice)
        {
            case 1:
                clientManager_.displayClients(output);
                break;
            case 2:
                if (!updateClient(input, output))
                {
                    output << "Input closed. Exiting program.\n";
                    return 0;
                }
                break;
            case 3:
                output << "Exiting program.\n";
                return 0;
            default:
                throw std::logic_error("Menu choice was not validated.");
        }
    }
}
