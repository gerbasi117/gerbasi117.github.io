#ifndef CLIENT_MANAGER_H
#define CLIENT_MANAGER_H

#include "Client.h"

#include <cstddef>
#include <iosfwd>
#include <vector>

// Owns the client list and checks each requested update.
class ClientManager
{
public:
    ClientManager();
    explicit ClientManager(std::vector<Client> clients);

    std::size_t getClientCount() const;
    void displayClients(std::ostream& output) const;
    bool updateClientService(std::size_t clientNumber, ServiceType service);

private:
    std::vector<Client> clients_;
};

#endif
