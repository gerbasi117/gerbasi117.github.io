#ifndef CLIENT_H
#define CLIENT_H

#include <string>

enum class ServiceType
{
    Brokerage = 1,
    Retirement = 2
};

// Stores one client's name and selected service.
class Client
{
public:
    Client(const std::string& name, ServiceType service);

    const std::string& getName() const;
    ServiceType getService() const;
    void setService(ServiceType service);

    static bool isValidService(ServiceType service);
    static std::string serviceToString(ServiceType service);

private:
    std::string name_;
    ServiceType service_;
};

#endif
